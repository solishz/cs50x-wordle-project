class Config:
    DEBUG = True
    TEMPLATES_AUTO_RELOAD = True